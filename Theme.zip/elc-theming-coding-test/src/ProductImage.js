import React from 'react';

export const ProductImage = ({ image,category }) =>
  <section>
    <h4 className="product-container__image_bread-crumb">{category}</h4>
    <figure>
      <img src={image} alt="Product" />
    </figure>
  </section>
    