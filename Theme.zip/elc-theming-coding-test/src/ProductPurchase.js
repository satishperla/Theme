import React from 'react';

import caret from './images/caret.png';
import minus from './images/minus.png';
import plus from './images/plus.png';

export const ProductPurchase = ({ price }) =>
  <section>
    <div className="product-container__description_container">
      <div className="product-container__description_qty">
        Quantity <img src={minus} alt="Decrease Quantity"/> 1 <img src={plus} alt="Increase Quantity"/>
      </div>
      <div className="product-container__description_otp">
        One Time Purchase  <img src={caret} alt="Select Frequency"/>
      </div>
    </div>
    <div className="product-container__description_container">
      <div className="product-container__description_price">{price}</div>
      <button name="AddToBag" className="product-container__description_addtobag">Add To Bag</button>
    </div>
  </section>