import React from 'react';
import { ProductDesc } from './ProductDesc';
import { ProductImage } from './ProductImage';
import { ProductPurchase } from './ProductPurchase';

import './styles/product.scss';

export const Product = ({ productData: { imgURL, category, name, description, ratingURL, features, shade, price } }) =>
	<main>
		<div className="product-container">
			<div className="product-container__image">
				<ProductImage image={imgURL} category={category} />
			</div>
			<div className="product-container__description">
				<ProductDesc 
				category={category}
				name={name}
				description={description}
				rating={ratingURL} 
				features={features} 
				shade={shade} />
				<hr/>
				<ProductPurchase price={price} />
			</div>
		</div>
	</main>
